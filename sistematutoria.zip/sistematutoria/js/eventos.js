

var inicioSesion = function()
{





}


//Evento inicial
$(document).on("ready",inicioSesion);